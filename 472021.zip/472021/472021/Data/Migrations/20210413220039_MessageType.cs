﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace _472021.Data.Migrations
{
    public partial class MessageType : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "MessageTypes",
                columns: new[] { "MessageTypeId", "Name" },
                values: new object[] { "z", "z Message" });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "MessageTypes",
                keyColumn: "MessageTypeId",
                keyValue: "z");
        }
    }
}
