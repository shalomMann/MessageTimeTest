﻿using _472021.Models;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.AspNetCore.Authorization;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.AspNetCore.Identity;
using System.Security.Cryptography;

namespace _472021.Data
{
    public class ApplicationDbContext : IdentityDbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        
        
        public DbSet<Message> Messages { get; set; }
        public DbSet<MessageType> MessageTypes { get; set; }

        
        

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            //var cook =  System.Text.Encoding.UTF8.GetBytes("AdminPassword1@");
            //var sha1 = new SHA1CryptoServiceProvider();
            //var sha1data = sha1.ComputeHash(cook);

            //var hashedPassword = new ASCIIEncoding().GetString(sha1data);

            //modelBuilder.Entity<IdentityUser>().HasData(
            //   new IdentityUser { UserName = "Administrator", Email = "admin@gmail.com", 
            //    PasswordHash = hashedPassword}
            //   );



            
            modelBuilder.Entity<MessageType>().HasData(
                new MessageType { MessageTypeId = "D", Name = "Daily Message" },
                new MessageType { MessageTypeId = "W", Name = "Weekly Message" },
                new MessageType { MessageTypeId = "M", Name = "Monthly Message" },
                new MessageType { MessageTypeId = "Y", Name = "Yearly Message" },
                new MessageType { MessageTypeId = "E", Name = "Event Message" },
                new MessageType { MessageTypeId = "O", Name = "One Time Message" }
                );
            
            modelBuilder.Entity<IdentityRole>().HasData(
                new IdentityRole { Id = "1", Name = "Admin"},
                new IdentityRole { Id = "2", Name = "BaseUser"}
                );

            //modelBuilder.Entity<AspNetUserClaims>

            modelBuilder.Entity<IdentityUserClaim<string>>().HasData(
               //change userId to the admin users ID string
                new IdentityUserClaim<string>
                {
                    ClaimType = "Role",
                    ClaimValue = "Admin",
                    UserId = "6f5d07f8-c694-4236-a067-43cd60bdd801",
                    Id = -3
                }
                );

            modelBuilder.Entity<IdentityUserRole<string>>().HasData(
                new IdentityUserRole<string> { RoleId = "1",
                    UserId = "6f5d07f8-c694-4236-a067-43cd60bdd801"
                }
                );
            modelBuilder.Entity<IdentityRoleClaim<string>>().HasData(
                new IdentityRoleClaim<string> { RoleId = "1", Id = 1}
                );
            
        }

    }

    
}
