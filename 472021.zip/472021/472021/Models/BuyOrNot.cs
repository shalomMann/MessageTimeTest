﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace _472021.Models
{
    public class BuyOrNot
    {
        public bool IsBought { get; set; }
        public string WhoBought { get; set; }

        
    }
}
